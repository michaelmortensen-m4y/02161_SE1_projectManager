package application;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateServer {
// By: Michael Mortensen
	public Calendar getDate() {
		return new GregorianCalendar();
	}
}